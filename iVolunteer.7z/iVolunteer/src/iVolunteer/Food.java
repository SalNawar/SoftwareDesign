package iVolunteer;
import java.util.Scanner;

public interface Food {
	
	
	String restaurantA = "Pizza Pizza";
	String restaurantB = "Pita Deli";	
	String restaurantC = "A&W";
	static Scanner serviceInput = new Scanner(System.in);
	
	public static int Provider(){
		int i;
		
	System.out.println("The Following restaurants are offering free food to deliver" );
	System.out.println("1."+restaurantA);
	System.out.println("2."+restaurantB);
	System.out.println("3."+restaurantC);
	System.out.println("Enter a restaurant number to register or 0 to exit");
	i = serviceInput.nextInt();
	if (i == 0 ){System.out.println("Goodbye" );return 0;}
	else if (i == 1){System.out.println("you registered for restaurant "+restaurantA); return 1;}
	else if (i == 2){System.out.println("you registered for restaurant "+restaurantB); return 2;}
	else if (i == 3){System.out.println("you registered for restaurant "+restaurantC); return 3;}
	else return 0;
	
	}
	
	
	
	
	

}
