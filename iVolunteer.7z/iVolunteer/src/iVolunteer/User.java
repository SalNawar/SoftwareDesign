package iVolunteer;

import java.util.Scanner;

public abstract class User extends ChooseService
	{
		private String name; 
		private String address;
		private String phone;
		private String email;
		public int chooseService(){ return super.chooseService();};
		public abstract void registerService();
		public abstract void setName();
		public abstract void setAddress(); 
		public abstract void setPhone();
		public abstract void setEmail();
		public abstract String getName();
		public abstract String getAddress(); 
		public abstract String getPhone();
		public abstract String getEmail();
		
		{
			
		}
	}
