package iVolunteer;

import java.util.Scanner;

public abstract class ChooseService {
	 static Scanner userInput = new Scanner(System.in);
	 int serviceNumber;
	 int i;
	public int chooseService()
	{
		System.out.println("Please choose a service by intering a number: 1. food , 2. clothes , 3. Medical Supplie, 4.Medical Help, 0. Exit ");
		for( ;i != 0 || i != 1; ){
		serviceNumber = userInput.nextInt();
		if(serviceNumber == 0){System.out.println("Goodbye"); return 0;}
		i = serviceNumber;
		
		if(serviceNumber == 1)
			{
			System.out.println("food services were choosen. Redirecting..");
		
			return 1;
			
			}
		else System.out.println("This service is not avalible, please re-enter 1 for food or 0 to exit");}
		
		return 0;
	}
	
}
