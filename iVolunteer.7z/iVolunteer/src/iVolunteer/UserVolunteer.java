package iVolunteer;
import java.util.Scanner;


public class UserVolunteer extends User implements Food {
	

	static UserVolunteer userVolunteer =  new UserVolunteer();
	Scanner userInput = new Scanner(System.in);
	private String name; 
	private String address;
	private String phone;
	private String email;
	private int service;  
	@Override
	public void registerService() {
		userVolunteer.setName();
		userVolunteer.setAddress();
		userVolunteer.setPhone();
		userVolunteer.setEmail();
		service = userVolunteer.chooseService();
		if (service == 1){  Food.Provider();}
		
	}

	@Override
	public int chooseService() {
		return super.chooseService();
		
	}

	@Override
	public void setName() {
		System.out.println("Enter your Name" );
		name = userInput.nextLine();
		
	}

	@Override
	public void setAddress() {
		System.out.println("Enter your Address" );
		address = userInput.nextLine();
		
	}

	@Override
	public void setPhone() {
		System.out.println("Enter your Phone" );
		phone = userInput.nextLine();
	}

	@Override
	public void setEmail() {
		System.out.println("Enter your Email" );
		email = userInput.nextLine();
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public String getAddress() {
		// TODO Auto-generated method stub
		return address;
	}

	@Override
	public String getPhone(){
		// TODO Auto-generated method stub
		return phone;
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
//	public static void main(String args[])
	//{
	
		//userVolunteer.registerService();
		
//	}


}
