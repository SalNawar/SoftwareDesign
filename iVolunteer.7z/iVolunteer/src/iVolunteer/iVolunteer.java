package iVolunteer;

public class iVolunteer extends UserVolunteer {
	
	public static void main(String args[])
	{
		UserVolunteer volunteer = new UserVolunteer();
		volunteer.registerService();
		
	}

}
