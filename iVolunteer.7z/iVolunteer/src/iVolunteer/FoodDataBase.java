package iVolunteer;

public abstract class FoodDataBase {

	private String Resturant; 
	private String Volunteer; 
	
	public void getInfo(){};
	public void updateInfo(){};
}
